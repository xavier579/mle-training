from setuptools import setup

setup(
   name='my_package',
   version='0.1.0',
   author='Harsh Saxena',
   author_email='',
   description='An awesome package that does something',
   install_requires=[
       "Django >= 1.1.1",
       "pytest",
   ],
)
